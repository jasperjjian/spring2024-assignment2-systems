# CS336 Spring 2024 Assignment 1: Basics

This folder contains the files from assignment 1 that you'll need for assignment
2, so you can do assignment 2 without having done assignment 1. **If you've
completed assignment 1, feel free to replace the contents of this directory with
your own implementation.**

Note that this is not a complete implementation of assignment 1, just the bits
that are carried forward for assignment 2.
